﻿using System.Collections;
using UnityEngine;
using TMPro;
using System;
using System.IO;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using Org.BouncyCastle.Security;
using Unity.Netcode;

public class ParentManager : MonoBehaviour
{
    [Header("Timer Variables")]
    public float timeStart = 0;
    public float timeSnapshot;
    public bool timerIsRunning = false;
    public TMP_Text timeText;
    [Header("Player Stats")]
    public CharacterStats stats;
    private RpcHandler rpcHandle;

    #region Timer
    public void DisplayTime(float timeToDisplay)
    {
        timeToDisplay += 1;
        float minutes = Mathf.FloorToInt(timeToDisplay / 60);
        float seconds = Mathf.FloorToInt(timeToDisplay % 60);
        timeText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    public void ToggleTimer(float startTime)
    {
        if (timerIsRunning)
        {
            timerIsRunning = false;
            timeStart = startTime;
            Debug.Log("stop timer");
        }
        else
        {
            timeStart = startTime;
            timerIsRunning = true;
            Debug.Log("begin timer");
            timeSnapshot = Time.time * 1000;
        }
    }
    #endregion


    #region Load Scenes

    public void LoadStart()
    {
        ChangeScene("Start");
    }
    public void LoadReach()
    {
        ChangeScene("Reach");
    }

    public void LoadPickUp()
    {
        ChangeScene("PickUp");
    }
    #endregion



    #region JSON Stuff

    protected string saveFile;



    public JsonPlayerStats readFile(string filename)
    {
        // Does the file exist?
        if (File.Exists(filename))
        {
            // Read the entire file and save its contents.
            string fileContents = File.ReadAllText(filename);

            // Deserialize the JSON data 
            //  into a pattern matching the GameData class.
            return JsonUtility.FromJson<JsonPlayerStats>(fileContents);
        }
        Debug.Log("file does not exist");
        Debug.Log(filename);
        return null;
    }
    #endregion

    [Header("Tracked Objects")]

    public GameObject pelvicBraceTracker;
    protected GameObject fruit;
    public GameObject headTracker;
    public GameObject handTracker;
    public GameObject chestTracker;
    public TMP_Dropdown directionDropdown;
    public bool grabbingFruit; //This bool will tell you whether the fruit is being grabbed or they are returning to rest position
    protected int runNum = 0;
    protected string fileName;
    [SerializeField] protected string workingDir;
    public void UpdateReport(string workingFile)
    {

        IDictionary<int, string> directions = new Dictionary<int, string>(){
            {0, "E"}, //E -> (angle, 
            {1, "NE"}, //NE
            {2, "N"}, //N
            {3, "NW"}, //NW
        };
        //user name, run #, chest height, current time, fruit position, hand position, chest position, head position, direction reach
        string[] data = new string[10];

        data[0] = stats.userName;

        data[1] = runNum.ToString();
        data[2] = stats.chestHeight.ToString();
        data[3] = timeStart.ToString();
        if (fruit != null)
            data[4] = fruit.transform.position.ToString("F4");
        else
            data[4] = "no fruit";


        data[5] = handTracker.transform.position.ToString("F4");
        data[6] = chestTracker.transform.position.ToString("F4");
        data[7] = headTracker.transform.position.ToString("F4");
        if (directionDropdown != null)
            data[8] = directions[directionDropdown.value];
        data[9] = grabbingFruit.ToString();
        //Debug.Log(fileName);
        CSVManager.AppendToReport(data, workingFile);
    }


    public void MakeDirectory()
    {

        DateTime dt = DateTime.Now;
        string date = dt.ToString("yyyy-MM-dd");
        //string date = DateTime.UtcNow.ToString("yyyyMMdd");
        workingDir = Application.dataPath + "/Reports/" + stats.userName + "/" + date;

        if (!Directory.Exists(workingDir))
        {
            //Debug.Log("here");
            //Debug.Log("Created report for " + stats.userName);
            Directory.CreateDirectory(workingDir);
            Directory.CreateDirectory(workingDir + "/Recorded");
            Directory.CreateDirectory(workingDir + "/Replay");
            Debug.Log("Created Directory for " + stats.userName);
        }

    }

    private void ChangeScene(string newScene)
    {
        if (rpcHandle == null)
            rpcHandle = FindObjectOfType<RpcHandler>();
        rpcHandle.SwitchScene(newScene);
    }
}