using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class RunCount : MonoBehaviour
{
    public TMP_Text runString;
    public CharacterStats stats;
    public GameObject inputField;
    private void Start() {
        //runString.text = "Input Run #";
    }
    public void UpdateRun() {
        if (int.TryParse(inputField.GetComponent<TMP_InputField>().text, out stats.run))
        {
            //runString.text = "Run #: " + stats.run.ToString();
        }
        //else
            //runString.text = "input valid num";
    }
}
