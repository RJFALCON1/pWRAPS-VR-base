using System.Collections;
using Unity.Netcode;
using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(LineRenderer))]
public class ArrowVF : MonoBehaviour
{
    private Transform startObject; // Assign your first GameObject
    public Transform endObject; // Assign your second GameObject
    private LineRenderer lineRenderer;

    [Header("Network Objects")]
    public GameObject networkMirror;
    public RpcHandler rpcHandle;

    public float closeDistance = 0.4f; // Set your own value
    public float farDistance = 1.0f; // Set your own value

    public float hideVFDistance = 0.2f; // Set your own value
    void Start()
    {
        startObject = GetComponent<Transform>();
        rpcHandle = FindObjectOfType<RpcHandler>();
        lineRenderer = GetComponent<LineRenderer>();
        if (startObject == null || endObject == null)
        {
            Debug.LogError("Start or End Object not assigned!");
        }
    }

    void Update()
    {
        if (startObject != null && endObject != null)
        {
            lineRenderer.SetPosition(0, startObject.position);
            lineRenderer.SetPosition(1, endObject.position);

            float distance = Vector3.Distance(startObject.position, endObject.position);
            if (distance <= hideVFDistance)
            {
                
                lineRenderer.enabled = false;
            }
            else
            {
                UpdateColorBasedOnDistance(distance);
                lineRenderer.enabled = true;
            }
            
        }
    }

    private void UpdateColorBasedOnDistance(float distance)
    {
        Color color;
        if (distance <= closeDistance)
            color = Color.green;
        else if (distance >= farDistance)
            color = Color.red;

        else
        {
            // Interpolate between green and red based on the distance
            float t = (distance - closeDistance) / (farDistance - closeDistance);
            color = Color.Lerp(Color.green, Color.red, t);
        }

        if (networkMirror)
        {
            var instanceNetworkObject = networkMirror.GetComponent<NetworkObject>();
            rpcHandle.vfColorUpdate(instanceNetworkObject.NetworkObjectId, color);
        }

        lineRenderer.material.color = color;
    }
}

