using System.Net.Http;
using System.Threading;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fruit : MonoBehaviour
{
    // Start is called before the first frame update
    public bool caught;
    public int fadeSpeed;
    MeshRenderer myMesh;

    private void Start() {
        myMesh = this.GetComponent<MeshRenderer>();
    }
    private void OnTriggerEnter(Collider other) {
        if(!caught && other.CompareTag("Basket")){
            caught = true;
            //Color myEndColor = new Color(0, 0, 0, 0f);
            if(this != null)
            {
                StartCoroutine(Destroy());
            }
           
            //StartCoroutine(FadeOutObject(myMesh,fadeSpeed, myMesh.material.color, myEndColor));
        }
    }
    private IEnumerator Destroy(){
        yield return new WaitForSeconds(3);
        Destroy(this.gameObject);
    }
    /*
    private IEnumerator FadeOutObject(MeshRenderer target_MeshRender,
        float lerpDuration, Color startLerp, Color targetLerp){

     float lerpStart_Time = Time.time;
     float lerpProgress;
     bool lerping = true;
     while (lerping)
     {
         yield return new WaitForEndOfFrame();
         lerpProgress = Time.time - lerpStart_Time;
         if (target_MeshRender != null)
         {
             target_MeshRender.material.color = Color.Lerp(startLerp, targetLerp, lerpProgress / lerpDuration);
         }
         else
         {
             lerping = false;
         }
         
         
         if (lerpProgress >= lerpDuration)
         {
             lerping = false;
         }
     }
     yield break;
 }*/
}
