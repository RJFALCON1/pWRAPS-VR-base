﻿using UnityEngine;

public class JsonPlayerStats
{
    public float armsLength;

    public float chestHeight;
    public float pelvicBraceHeight;
    public string userName;
    //Use north, south, east, and west to designate which direction the user is leaning
    public float maxReachE;
    public float maxReachNE;
    public float maxReachN;
    public float maxReachNW;
    public Vector3 startPos;
}