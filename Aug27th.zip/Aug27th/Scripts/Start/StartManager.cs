using System;
using TMPro;
using UnityEngine;

public class StartManager : ParentManager
{
    [Header("Control Buttons")]
    public GameObject startWindow;
    public GameObject loadButton;
    public GameObject newButton;
    public GameObject inputField;
    
    public TextMeshProUGUI curUser;
    public StatsHandler statsHandler;
    public string date;

    private CustomNetworkManager localNetMan;

    private void Start()
    {
        //instructions.CrossFadeAlpha(1.0f, 0, false);
        
        startWindow.SetActive(true);
        loadButton.SetActive(false);
        newButton.SetActive(false);
        inputField.SetActive(false);
        saveFile = Application.dataPath + "/Reports";
        date = DateTime.Now.ToString("yyyy-MM-dd");

        LinkNetworkManager();

    }

    public void StartCalibration()
    {
        //turn off the buttons
        startWindow.SetActive(false);

        Debug.Log("choose");

        inputField.SetActive(true);

    }

    public void GetUsername()
    {
        stats.userName = inputField.GetComponent<TMP_InputField>().text;
        inputField.SetActive(false);
        loadButton.SetActive(true);
        newButton.SetActive(true);
        curUser.text = "Current User: " + stats.userName;

    }

    public void BalloonSpawn()
    {
        statsHandler.ReachCalibrateInstructions(1);
    }
    public void NewStats()
    {
        loadButton.SetActive(false);
        newButton.SetActive(false);
        statsHandler.ArmLengthCalibrateInstructions();
        MakeDirectory();
    }
    public void LoadStats()
    {
        JsonPlayerStats jsonStats = readFile(saveFile + "/" + stats.userName + "/" + date + "/" + stats.userName + "_Data.json");
        Debug.Log(saveFile + "/" + stats.userName + "/" + date + "/" + stats.userName + "_Data.json");
        Reset();

        //load data from json into player stats
        if (jsonStats != null)
        {
            stats.userName = jsonStats.userName;
            stats.chestHeight = jsonStats.chestHeight;
            stats.pelvicBraceHeight = jsonStats.pelvicBraceHeight;
            stats.armsLength = jsonStats.armsLength;
            stats.maxReachE = jsonStats.maxReachE;
            stats.maxReachN = jsonStats.maxReachN;
            stats.maxReachNE = jsonStats.maxReachNE;
            stats.maxReachNW = jsonStats.maxReachNW;
            stats.startPos = jsonStats.startPos;
            Debug.Log("loaded stats");
            curUser.text = "Current User: " + stats.userName + " - Loaded!";
        }
        else
        {
            curUser.text = "Current User: DNE reset and try again";
        }

    }

    public void Reset()
    {
        //turn on the buttons
        startWindow.SetActive(true);
        loadButton.SetActive(false);
        newButton.SetActive(false);
        inputField.SetActive(false);
        stats.Reset();
        statsHandler.Reset();
        //Debug.Log("Show Buttons");
    }

    private void LinkNetworkManager()
    {
        localNetMan = FindObjectOfType<CustomNetworkManager>();

        if (localNetMan == null)
            Debug.Log("WARNING: Network Manager could not be found");
    }

}
