using System.IO;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PositionData
{
    public List<Vector3> positions = new List<Vector3>();
}

public class PositionLogger : MonoBehaviour
{
    private PositionData positionData = new PositionData();
    private string filePath;

    void Start()
    {
        filePath = Path.Combine(Application.persistentDataPath, "tracker_positions.json");
    }

    public void SavePosition(Vector3 position)
    {
        positionData.positions.Add(position);
        string jsonData = JsonUtility.ToJson(positionData, true);
        File.WriteAllText(filePath, jsonData);
        Debug.Log("Position saved: " + position);
    }
}
