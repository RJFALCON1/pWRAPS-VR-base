using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Valve.VR.InteractionSystem{
    public class Pointer : MonoBehaviour
{
    public float length = 5.0f;
    public GameObject m_Dot;
    public GameObject hand; //public SteamVR_Input_Sources handType; works if this doesn't

    private LineRenderer m_LineRenderer = null;

    // Start is called before the first frame update
    private void Awake() {
        
    }

    // Update is called once per frame
    void Update()
    {
        UpdateLine();
         //if (SteamVR_Input._default.inActions.GrabGrip.GetStateDown(inputSource))
           // Debug.Log("grab grip"); // the side button on the controller
    }
    private void UpdateLine(){
        //use default or distance
        float targetLength = length;

        //Raycast
        RaycastHit hit = Createraycast(targetLength);
        
        //Default
        Vector3 endPosition = transform.position + (transform.forward * targetLength);
        //or based on hit
        if(hit.collider !=null){
            endPosition = hit.point;
        }
        //Set linerenderer
        m_LineRenderer.SetPosition(0, hand.transform.position);
        m_LineRenderer.SetPosition(1, endPosition);
    }
    private RaycastHit Createraycast(float length){
        RaycastHit hit;
        Ray ray = new Ray(transform.position, transform.forward);
        Physics.Raycast(ray, out hit, length);
        return hit;
    }
}

}
