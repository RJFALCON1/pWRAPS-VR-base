﻿using System;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using UnityEditor.IMGUI.Controls;

public static class CSVManager {


    private static string reportDirectoryName = "Reports";
    private static string reportSeparator = ",";
    private static string[] reportHeaders = new string[] {
        "run #",
        "current time (ms)",
        "chest x", "chest y", "chest z",
        "fruit x", "fruit y", "fruit z",
        "hand x", "hand y", "hand z",
        "max percentage",
        "collision"
    };

#region Interactions

    public static void AppendToReport(string[] strings, string name = "test") {
        //VerifyDirectory();
        //VerifyFile();
        using (StreamWriter sw = File.AppendText(name +".csv")) {
            string finalString = "";
            for (int i = 0; i < strings.Length; i++) {
                if (finalString != "") {
                    finalString += reportSeparator;
                }
                finalString += strings[i];
            }
            sw.WriteLine(finalString);
        }
    }
    public static List<Vector3> ReadCSVFileForPos(string file)
    {
        List<Vector3> posList = new List<Vector3>();
        string[] lines = File.ReadAllLines(file + ".csv");
        
        for (int line = 1; line < lines.Length; line++)
        {
            string[] cols = lines[line].Split(',');
            posList.Add(new Vector3(float.Parse(cols[8]), float.Parse(cols[9]), float.Parse(cols[10])));
        }

        return posList;
    }

    public static string CreateReport(string name = "test") {
        
        Debug.Log("Creating report at " + name);
        using (StreamWriter sw = File.CreateText(name+".csv"))
        {
            string finalString = "";
            for (int i = 0; i < reportHeaders.Length; i++)
            {
                if (finalString != "")
                {
                    finalString += reportSeparator;
                }
                finalString += reportHeaders[i];
            }

            sw.WriteLine(finalString);
        }
        return name;
    }

#endregion


}
