using System.Net.Http;
using System.Threading;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Valve.VR.InteractionSystem;
using Valve.VR;
using Valve.VR.Extras;

namespace Valve.VR.InteractionSystem
{
    public class Fruit : MonoBehaviour
    {
        // Start is called before the first frame update
        public bool caught;
        public int fadeSpeed;
        MeshRenderer myMesh;

        private void Start()
        {
            myMesh = this.GetComponent<MeshRenderer>();
        }

      


        private void OnTriggerEnter(Collider other)
        {
            if (!caught && other.CompareTag("Basket"))
            {
                caught = true;
                //Color myEndColor = new Color(0, 0, 0, 0f);
                //Debug.Log("in basket");
                //StartCoroutine(FadeOutObject(myMesh,fadeSpeed, myMesh.material.color, myEndColor));
            }
           
        }

        public void DestroyFruit()
        {
            StartCoroutine(Destroy());
        }
        private IEnumerator Destroy()
        {
            
            yield return new WaitForSeconds(0.1f);
            //this.gameObject.GetComponent<Interactable>().enabled = false;
            Destroy(this.gameObject);
        }
        /*
        private IEnumerator FadeOutObject(MeshRenderer target_MeshRender,
            float lerpDuration, Color startLerp, Color targetLerp){

         float lerpStart_Time = Time.time;
         float lerpProgress;
         bool lerping = true;
         while (lerping)
         {
             yield return new WaitForEndOfFrame();
             lerpProgress = Time.time - lerpStart_Time;
             if (target_MeshRender != null)
             {
                 target_MeshRender.material.color = Color.Lerp(startLerp, targetLerp, lerpProgress / lerpDuration);
             }
             else
             {
                 lerping = false;
             }
         
         
             if (lerpProgress >= lerpDuration)
             {
                 lerping = false;
             }
         }
         yield break;
     }*/
    }
}
