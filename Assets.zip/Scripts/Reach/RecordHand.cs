using RosMessageTypes.Geometry;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using Unity.Robotics.ROSTCPConnector.ROSGeometry;
using Unity.VisualScripting.Antlr3.Runtime.Misc;
using UnityEngine;

public class RecordHand : MonoBehaviour
{

    public Transform handPos;

    // Publish the cube's position and rotation every N seconds
    public float publishMessageFrequency = 0.5f;
    public bool update = false;
    // Used to determine how much time has elapsed since the last message was published
    private float timeElapsed;

    private string fileName;

    string userName = "bob";
    // Start is called before the first frame update
    void Start()
    {
        MakeReport();
    }

    // Update is called once per frame
    void Update()
    {
        timeElapsed += Time.deltaTime;

        if (timeElapsed > 1 / publishMessageFrequency && update)
        {

            UpdateReport(handPos);
            

            timeElapsed = 0;
        }
    }

    public void UpdateReport(Transform tracker)
    {
        //user name, run #, chest height, current time, fruit position, hand position, chest position, head position, direction reach
        //Debug.Log(fileName);
        string date = DateTime.UtcNow.ToString("yyyy-MM-dd");
        CSVManager.AppendToReport(new string[] { tracker.ToString() }, Application.dataPath + "/Reports/" + userName + "_Runs/" + date+ "/"+ fileName);
    }

    public void MakeReport(string userName =  "bob")
    {

        //DateTime dt = DateTime.Now;
        //string date = dt.ToString("yyyy-MM-dd\\Z");
        string date = DateTime.UtcNow.ToString("yyyy-MM-dd");
        string dir = Application.dataPath + "/Reports/" + userName + "_Runs/" + date;
        if (!Directory.Exists(dir))
        {
            //Debug.Log("here");
            //Debug.Log("Created report for " + stats.userName);
            Directory.CreateDirectory(dir);
        }
        
        fileName = "Run_" + userName;
        CSVManager.CreateReport(dir + "/" + fileName);
        Debug.Log("Created report for " + userName);

    }
}
