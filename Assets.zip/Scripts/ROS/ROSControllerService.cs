using RosMessageTypes.Chawi;
using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using Cinemachine.Utility;

public class ROSControllerService : MonoBehaviour
{
    ROSConnection ros;

    public string serviceName = "ctrl_srv";
    public ReachManager reachManager;
    public ReachVRResponse reachResponse;
    void Start()
    {
       
        reachResponse.reach_success = false;
        // register the service with ROS
        ROSConnection.GetOrCreateInstance().ImplementService<ReachVRRequest, ReachVRResponse>(serviceName, GetResponse);
    }


    private ReachVRResponse GetResponse(ReachVRRequest request)
    {
        reachResponse = new ReachVRResponse();
        Debug.Log("Service called!");
        
        Debug.Log(request.ToString());
        //Update the game with the request parameters
        bool record = false;
        bool cntrlF = true;

        if (request.vr_condition == "non")
            record = true;


        if (request.vr_condition == "ctl")
            cntrlF = true;
        else if (request.vr_condition == "err")
            cntrlF = false;
        reachManager.timeToReach = request.time_limit;
        reachManager.StartGame((int)request.direction_deg, request.height_pc_torso, request.distance_pc_max, request.speed, record, cntrlF, request.rep );

        

        while (!reachResponse.reach_success) { }

        Debug.Log("Sending response: " + reachResponse.ToString());
        
        //GetGeometryPoint(reachManager.handTracker.transform.position.Unity2Ros(), response.target_position.point);


        return reachResponse;
    }
}