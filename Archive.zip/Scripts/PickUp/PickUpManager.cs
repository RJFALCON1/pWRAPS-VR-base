using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

using System;
using UnityEngine.SceneManagement;

using System.IO;
using Assimp.Unmanaged;
using System.Security.Cryptography;
using System.Net.NetworkInformation;
using UnityEngine.Rendering.Universal;
using UnityEngine.Windows;
using Unity.Robotics.ROSTCPConnector.ROSGeometry;

public class PickUpManager : ParentManager
{
    //Prefabs to Instantiate
    [Header("Prefabs to Instantiate")]
    public GameObject table;
    public GameObject player;
    public GameObject basket;
    

    [Header("Variables to handle fruit and box spawn")]
    //handle the spawn
    public float scale;
    public float minAngle;
    public float maxAngle;
    public float boxAngle;

    //list of objects to spawn
    [Header("List of Objects to Spawn")]
    public List<GameObject> objects = new List<GameObject>();

    [Header("Input Fields")]
    public TMP_InputField percentReach;
    public TMP_Text runText;

    public Toggle cntrlVFToggle;
    public Toggle recordToggle;
    public TMP_Text resetHandText;
    public GameObject startButton;
    public TMP_Text directionText;

    [Header("Others")]    
    public float chestOffset = 1;

    public SignalSender updateRun;

    public float timeToReach = 5;
    public float timeToRest = 3f;
    public bool IsResting = false;
    public string waitString = "Rest for 3 seconds!";

    IDictionary<int, (int, float)> ROSdirections;
    public RosReachVRService rosReachVRService;
    public GameObject rightHand;
    private void Start()
    {

        ROSdirections = new Dictionary<int, (int, float)>(){
            {0, (270, stats.maxReachE)}, //E -> (angle, 
            {45, (215, stats.maxReachNE)}, //NE
            {90, (180, stats.maxReachN)}, //N
            {135, (135, stats.maxReachNW)}, //NW
        };
    }

    private void Update()
    {

        if (timeStart == 0 && timerIsRunning) // rare case
        {
            resetHandText.text = waitString;
            if (IsResting)
            {
                ToggleTimer(timeToRest);
                DisplayTime(timeStart);
                IsResting = false;  // only rest once after the end of each session
            }
            startButton.SetActive(true);
            directionText.gameObject.SetActive(true);
            resetHandText.gameObject.SetActive(false);
            //resetHandText.gameObject.SetActive(true);
            ToggleTimer(timeToReach);
        }
        if (timerIsRunning)
        {
            timeStart -= Time.deltaTime;
            if (timeStart < 0)
            {
                //this resets the clock
                DisplayTime(timeStart);
                ToggleTimer(timeToReach);
                ResetRound();
                resetHandText.text = waitString;
                if (IsResting)
                {
                    ToggleTimer(timeToRest);
                    DisplayTime(timeToRest);
                    IsResting = false;  // only rest once after the end of each session
                }
                startButton.SetActive(true);
                directionText.gameObject.SetActive(false);
                resetHandText.gameObject.SetActive(true);
            }
            else
                DisplayTime(timeStart);
        }

    }

    bool gotStartPos = false;
    Vector3 startPos;

    public void StartGame(int direction, float torso_pc, float reach_pc, float speed, bool record, string boxDir, int rep)
    {
        Debug.Log("started");
        directionText.gameObject.SetActive(true);
        resetHandText.gameObject.SetActive(false);
        if (!gotStartPos)
        {
            startPos = player.transform.position;
            gotStartPos = true;
        }

        GameObject[] spawnedObjects = GameObject.FindGameObjectsWithTag("Fruit");
        if (spawnedObjects.Length != 0)
        {
            foreach (GameObject thing in spawnedObjects)
            {
                Destroy(thing);
            }
        }
        spawnedObjects = GameObject.FindGameObjectsWithTag("Basket");
        if (spawnedObjects.Length != 0)
        {
            foreach (GameObject thing in spawnedObjects)
            {
                Destroy(thing);
            }
        }



        (int, float) directionChoice = ROSdirections[direction];


        // Spawn friut distance
        float fruitDistance = directionChoice.Item2 * reach_pc / 100;


        float spawnHeight = ((stats.chestHeight - stats.pelvicBraceHeight) * (torso_pc-5) / 100) + stats.pelvicBraceHeight;

       
        //spawn table if not there
        if (GameObject.FindWithTag("Table") == null)
        {
            Vector3 tablePosition = new Vector3(player.transform.position.x, spawnHeight, player.transform.position.z - stats.armsLength);
            Instantiate(table, tablePosition, Quaternion.identity);
        }

        //spawn fruit
        Vector3 pos = PosOnCircle(startPos, fruitDistance, directionChoice.Item1, 2);
        Debug.Log("Fruit  " + directionChoice.Item1);
        int index = UnityEngine.Random.Range(0, objects.Count);
        fruit = Instantiate(objects[index], pos, Quaternion.identity) as GameObject;
        fruit.transform.localScale = new Vector3(scale, scale, scale);
        
        //spawn box
        if (boxDir == "right")
            boxAngle = 215;
        else if (boxDir == "left")
            boxAngle = 135;

        Vector3 basketPosition = PosOnCircle(startPos, fruitDistance * 0.5f, boxAngle, 2);
        Debug.Log("Basket pos: " +  boxAngle);
        Instantiate(basket, basketPosition, Quaternion.identity);
        //updateRun.Raise();
        rosReachVRService.reachResponse.target_position.point = fruit.transform.position.To<FLU>();
        rosReachVRService.reachResponse.start_hand_pose.pose.position = rightHand.transform.position.To<FLU>();
        if (!timerIsRunning)
        {
            ToggleTimer(timeToReach);
            IsResting = true; // when the reach 0 it will start another 3 s timer once
        }
    }


    public void StartGame(){
        directionText.gameObject.SetActive(true);
        resetHandText.gameObject.SetActive(false);
        if (!gotStartPos)
        {
            startPos = player.transform.position;
            gotStartPos = true;
        }

        GameObject[] spawnedObjects = GameObject.FindGameObjectsWithTag("Fruit");
        if(spawnedObjects.Length != 0){
            foreach(GameObject thing in spawnedObjects){
                Destroy(thing);
            }
        }
        spawnedObjects = GameObject.FindGameObjectsWithTag("Basket");
        if(spawnedObjects.Length != 0){
            foreach(GameObject thing in spawnedObjects){
                Destroy(thing);
            }
        }
        float angle = UnityEngine.Random.Range(minAngle,maxAngle);
        Vector3 pos = PosOnCircle(startPos, stats.armsLength, 90, 2);
        int index = UnityEngine.Random.Range(0, objects.Count);
        fruit = Instantiate(objects[index], pos, Quaternion.identity) as GameObject;
        fruit.transform.localScale = new Vector3(scale, scale, scale);
        //fruitCount++;

        //spawns the table, basket and creates a report with the user's name
        // Vector3 basketPosition;
        // if(angle + boxAngle > maxAngle){
        //     angle = minAngle + (angle + boxAngle-maxAngle);
        // }
        // else{
        //     angle = angle + boxAngle;
        // }
        float spawnHeight = ((stats.chestHeight - stats.pelvicBraceHeight) + stats.pelvicBraceHeight);
        if (GameObject.FindWithTag("Table") == null){
            Vector3 tablePosition = new Vector3(player.transform.position.x, spawnHeight, player.transform.position.z - stats.armsLength);
            Instantiate(table, tablePosition, Quaternion.identity);
        }
        boxAngle = UnityEngine.Random.Range(minAngle,maxAngle);
        while(boxAngle +30 >angle && boxAngle -30 <angle){
             boxAngle = UnityEngine.Random.Range(minAngle,maxAngle);
        }
        Vector3 basketPosition = PosOnCircle(startPos, stats.armsLength, boxAngle, 2);
        //if(GameObject.Find("Table(Clone)") == null)
        //{
        //    Vector3 tablePosition = new Vector3(player.transform.position.x, stats.chestHeight + chestOffset, player.transform.position.z - stats.armsLength);
        //    Instantiate(table, tablePosition, Quaternion.identity);
        //}
        //fruitCount++;


        //need to change the position of the basket
        Instantiate(basket, basketPosition, Quaternion.identity);
        //updateRun.Raise();
        if (!timerIsRunning)
        {
            ToggleTimer(timeToReach);
            IsResting = true; // when the reach 0 it will start another 3 s timer once
        }
    }

    public void ResetField(){
        startButton.SetActive(true);
        directionText.gameObject.SetActive(false);
        resetHandText.gameObject.SetActive(false);
        if (timerIsRunning)
        {
            ToggleTimer(0);
        }
        GameObject[] objects = GameObject.FindGameObjectsWithTag("Fruit");
        if(objects.Length != 0){
            foreach(GameObject thing in objects){
                Destroy(thing);
            }
        }
        objects = GameObject.FindGameObjectsWithTag("Basket");
        if(objects.Length != 0){
            foreach(GameObject thing in objects){
                Destroy(thing);
            }
        }
        objects = GameObject.FindGameObjectsWithTag("Table");
        if(objects.Length != 0){
            foreach(GameObject thing in objects){
                Destroy(thing);
            }
        }
        //ToggleTimer(5);
    }

    public void ResetRound()
    {

        GameObject[] objects = GameObject.FindGameObjectsWithTag("Fruit");
        if (objects.Length != 0)
        {
            foreach (GameObject thing in objects)
            {
                Destroy(thing);
            }
        }
        objects = GameObject.FindGameObjectsWithTag("Basket");
        if (objects.Length != 0)
        {
            foreach (GameObject thing in objects)
            {
                Destroy(thing);
            }
        }
        
    }

    private Vector3 PosOnCircle(Vector3 center, float radius, float a, float height)
    {
        //Debug.Log(a);
        float ang = a;
        Vector3 pos;
        pos.x = center.x + radius * Mathf.Sin(ang * Mathf.Deg2Rad);
        pos.z = center.z + radius * Mathf.Cos(ang * Mathf.Deg2Rad);
        pos.y = height;
        return pos;
    }
}
