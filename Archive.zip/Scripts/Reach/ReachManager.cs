
using System.Collections.Generic;
using UnityEngine;

using TMPro;
using System.IO;
using System;
using UnityEngine.SceneManagement;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.Experimental.XR.Interaction;
using Valve.VR;
using UnityEngine.Rendering.Universal;
using UnityEngine.Windows;
using static UnityEngine.SpatialTracking.TrackedPoseDriver;
using Unity.Robotics.ROSTCPConnector.ROSGeometry;
using Mirror;

public class ReachManager : ParentManager
{
    //Prefabs to Instantiate
    [Header("Prefabs to Instantiate")]
    public GameObject player;


    [Header("Variables to handle fruit spawn")]
    //handle the spawn
    public float scale;
    public int angleRange;
    public float timeToReach = 10;
    public float timeToRest = 3;

    public bool IsResting = false;

    //list of objects to spawn
    [Header("List of Objects to Spawn")]
    public List<GameObject> objects = new List<GameObject>();

    [Header("Input Fields")]
    public TMP_InputField percentReach;
    public TMP_Text runText;

    public Toggle cntrlVFToggle;
    public Toggle recordToggle;
    public TMP_Text resetHandText;
    public GameObject startButton;
    public TMP_Text directionText;

    [Header("Others")]
    public float chestOffset = 1;
    private AudioSource ding;

    public RosReachVRService rosReachVRService;

    // Direction of the fruit
    IDictionary<int, (int, float)> ROSdirections;
    public SteamVR_Action_Boolean input;
    public SteamVR_Input_Sources handType;
    public GameObject rightHand;

    private Vector3 reachStartPos;
    private RpcHandler rpcHandle;
    private Vector3 fruitPos;

    private void Start()
    {
        reachStartPos = GameObject.Find("ChestTracker").transform.position;

        input.AddOnStateDownListener(TriggerDown, handType);

        startButton.SetActive(true);
        ding = this.GetComponent<AudioSource>();

        ROSdirections = new Dictionary<int, (int, float)>(){
            {0, (270, stats.maxReachE)}, //E -> (angle, 
            {45, (215, stats.maxReachNE)}, //NE
            {90, (180, stats.maxReachN)}, //N
            {135, (135, stats.maxReachNW)}, //NW
        };

        rpcHandle.DespawnRequest(rpcHandle.RetrRegObj("h0"));
        rpcHandle.DespawnRequest(rpcHandle.RetrRegObj("h1"));
    }

    private void Update()
    {
        if (timeStart == 0 && timerIsRunning) // rare case
        {
            directionText.text = waitString;
            if (IsResting)
            {
                ToggleTimer(timeToRest);
                DisplayTime(timeStart);
                IsResting = false;  // only rest once after the end of each session
            }
            startButton.SetActive(true);
            directionText.gameObject.SetActive(true);
            resetHandText.gameObject.SetActive(false);
            //resetHandText.gameObject.SetActive(true);
            ToggleTimer(timeToReach);
        }
        if (timerIsRunning)
        {
            timeStart -= Time.deltaTime;
            if (timeStart < 0)
            {
                //this resets the clock
                DisplayTime(timeStart);
                ToggleTimer(timeToReach);
                DestroyFruit();
                directionText.text = waitString;
                if (IsResting)
                {
                    ToggleTimer(timeToRest);
                    DisplayTime(timeStart);
                    IsResting = false;  // only rest once after the end of each session
                }
                startButton.SetActive(true);
                directionText.gameObject.SetActive(true);
                resetHandText.gameObject.SetActive(false);
            }
            else
                DisplayTime(timeStart);
        }

    }

    //50Hz
    private float accumulatedTime = 0f; // Stores the accumulated time
    public float frequencyInHz = 50f;   // Default to 50 Hz. You can adjust this value.
    //private string workingFile;
    private string workingFruitFile;
    private void FixedUpdate()
    {
        if (timerIsRunning)
        {
            accumulatedTime += Time.fixedDeltaTime;

            float reportInterval = 1f / frequencyInHz; // Convert Hz to an interval in seconds.

            if (accumulatedTime >= reportInterval)
            {
                if (recordToggle.isOn)
                {
                    LogFruitLocation(workingFruitFile);
                }
                accumulatedTime = 0; // Reset or subtract to account for potential overflow.
            }
        }
    }

    public void LogFruitLocation(string filename)
    {
       /*    "run #",                                       0
        *    "current time",                                1
        *    "chest x", "chest y", "chest z",               2-4
        *    "fruit x", "fruit y", "fruit z",               5-7
        *    "hand x", "hand y", "hand z",                  8-10
        *    "max percentage",                              11
        *    "collision"                                    12
        */

        string handPos = handTracker.transform.position[0].ToString();
        Vector3[] targets = new Vector3[3]{chestTracker.transform.position, fruitPos, handTracker.transform.position};
        string[] data = new string[16];

        int j = 0;
        for (int i = 2; i < 10; i = i + 3)
        {
            data[i] = targets[j][0].ToString();
            data[i + 1] = targets[j][1].ToString();
            data[i + 2] = targets[j][2].ToString();
            j++;
        }

        data[0] = runNum.ToString();
        data[1] = ((Time.time * 1000) - timeSnapshot).ToString();
        data[11] = percentReach.text;
        data[12] = (grabbingFruit != true).ToString();

        CSVManager.AppendToReport(data, filename);


    }

    #region VF
    public GameObject controlVF; // Assign the GameObject you want to move in the Inspector

    private List<Vector3> positions = new List<Vector3>();
    private int currentPositionIndex = 0;

    string waitString = "Rest for 3 seconds!";
    private IEnumerator UpdateControlVF(float speed)
    {
        //modify the delay for the feedback to show
        LocateRpcHandler();
        rpcHandle.SpawnRequest("StreamObjectMirror", controlVF.transform.position, "vf");
        yield return new WaitForSeconds(1f);

        controlVF.SetActive(true);
        controlVF.GetComponent<MeshRenderer>().enabled = true;

        /* Spawns an object mirror and links it to the object */
        ObjSync mirrorSync = rpcHandle.RetrRegObj("vf").GetComponent<ObjSync>();
        mirrorSync.MirrorTarget = controlVF.transform;
        controlVF.GetComponent<ArrowVF>().networkMirror = rpcHandle.RetrRegObj("vf");

        Debug.Log("Starting UpdateTargetPosition coroutine");

        controlVF.GetComponent<ArrowVF>().enabled = false;
        controlVF.GetComponent<LineRenderer>().enabled = false;
        while (true)
        {
            if (currentPositionIndex < positions.Count)
            {
                controlVF.transform.position = positions[currentPositionIndex];
                currentPositionIndex++;
            }
            else
            {
                currentPositionIndex = 0;
                controlVF.SetActive(false);
                rpcHandle.DespawnRequest(rpcHandle.RetrRegObj("vf"));
                break;
            }

            yield return new WaitForSeconds(1f / (frequencyInHz * speed)); // update the positiotn the same amount of times as the ROS service
        }
    }

    private IEnumerator UpdateErrorVF(float speed)
    {
        LocateRpcHandler();
        rpcHandle.SpawnRequest("StreamObjectMirror", controlVF.transform.position, "vf");
        //modify the wait time for the feedback to show
        yield return new WaitForSeconds(1f);

        controlVF.SetActive(true);

        /* Spawns an object mirror and links it to the object */
        ObjSync mirrorSync = rpcHandle.RetrRegObj("vf").GetComponent<ObjSync>();
        mirrorSync.MirrorTarget = controlVF.transform;
        controlVF.GetComponent<ArrowVF>().networkMirror = rpcHandle.RetrRegObj("vf");

        controlVF.GetComponent<MeshRenderer>().enabled = false;
        controlVF.GetComponent<ArrowVF>().enabled = true;
        controlVF.GetComponent<LineRenderer>().enabled = true;
        while (true)
        {
            if (currentPositionIndex < positions.Count)
            {
                controlVF.transform.position = positions[currentPositionIndex];
                currentPositionIndex++;
            }
            else
            {
                currentPositionIndex = 0;
                controlVF.SetActive(false);
                rpcHandle.DespawnRequest(rpcHandle.RetrRegObj("vf"));
                break;
            }

            yield return new WaitForSeconds(1f / (frequencyInHz * speed)); // update the positiotn the same amount of times as the ROS service
        }
    }
    #endregion

    List<string> dirToText = new List<string>() {"right", "front right", "front", "front left"};   // (angle / 45)

    // Start Game called by the ROS Service
    bool recordHandPos = false;
    bool gotStartPos = false;
    Vector3 startPos;
    public void StartGame(int direction, float torso_pc, float reach_pc, float speed, bool record, bool cntrlVF, int rep)
    {
        LocateRpcHandler();

        if (!gotStartPos)
        {
            startPos = GameObject.Find("ChestTracker").transform.position;
            gotStartPos = true;
        }

        startButton.SetActive(false);
        grabbingFruit = true;
        runNum++;

        rpcHandle.TextUpdatesStatusOn(true);
        rpcHandle.TextUpdates("Run: " + runNum.ToString());

        MakeDirectory();
        recordHandPos = record;
        if (record)
        {
            Debug.Log(workingDir);
            fileName = direction.ToString() + "_record";
            Debug.Log(workingDir + "/Recorded/" + fileName);
            workingFruitFile = CSVManager.CreateReport(workingDir + "/Recorded/" + fileName);

        }
        else
        {
            positions = CSVManager.ReadCSVFileForPos(workingDir + "/Recorded/" + direction.ToString() + "_record");
            Debug.Log("Positions from: " + workingDir + "/Recorded/" + direction.ToString() + "_record");
            fileName = direction.ToString() + "_replay_" + rep.ToString();
            workingFruitFile = CSVManager.CreateReport(workingDir + "/Replay/" + fileName);
            if (cntrlVF)
                StartCoroutine(UpdateControlVF(speed));
            else
                StartCoroutine(UpdateErrorVF(speed));

        }
        DestroyFruit();

        // Choose the direction and the corresponding max distance
        (int, float) directionChoice = ROSdirections[direction];


        // Spawn fruit distance
        float fruitDistance = directionChoice.Item2 * reach_pc / 100;


        float spawnHeight = ((stats.chestHeight - stats.pelvicBraceHeight) * torso_pc / 100) + stats.pelvicBraceHeight;

        Vector3 pos = PosOnCircle(startPos, fruitDistance, directionChoice.Item1, spawnHeight);
        fruitPos = pos;
        int index = UnityEngine.Random.Range(0, objects.Count);

        rpcHandle.SpawnRequest(objects[index].name, pos, "fruit");
        rpcHandle.TextUpdates("Look to the " + dirToText[(int)direction / 45]);

        rosReachVRService.reachResponse.target_position.point = pos.To<FLU>();
        rosReachVRService.reachResponse.start_hand_pose.pose.position = rightHand.transform.position.To<FLU>();

        if (!timerIsRunning)
        {
            ToggleTimer(timeToReach);
            IsResting = true; // when the reach 0 it will start another 3 s timer once
        }

    }

    // Start game called by pressinsg the start button
    public void StartGame()
    {
        LocateRpcHandler();

        startButton.SetActive(false);
        grabbingFruit = true;
        runNum++;

        rpcHandle.TextUpdatesStatusOn(true);
        rpcHandle.TextUpdates("Run: " + runNum.ToString());

        DestroyFruit();

        int direction = int.Parse(directionDropdown.options[directionDropdown.value].text);
        (int, float) directionChoice = ROSdirections[direction];

        int angleOffset = UnityEngine.Random.Range(0, angleRange);

        float percent;
        float.TryParse(percentReach.text, out percent);
        float fruitDistance = stats.armsLength * percent / 100;

        bool record = recordToggle.isOn;
        bool cntrlVF = cntrlVFToggle.isOn;

        MakeDirectory();
        if (record)
        {
            Debug.Log(workingDir);
            fileName = direction.ToString() + "_record";
            Debug.Log(workingDir + "/Recorded/" + fileName);
            workingFruitFile = CSVManager.CreateReport(workingDir + "/Recorded/" + fileName);
        }
        else
        {
            positions = CSVManager.ReadCSVFileForPos(workingDir + "/Recorded/" + direction.ToString() + "_record");
            Debug.Log("Positions from: " + workingDir + "/Recorded/" + direction.ToString() + "_record");

            fileName = direction.ToString() + "_replay";
            workingFruitFile = CSVManager.CreateReport(workingDir + "/Replay/" + fileName);
            if (cntrlVF)
            {
                StartCoroutine(UpdateControlVF(1f));
            }
            else
                StartCoroutine(UpdateErrorVF(1f));
        }

        if (fruitDistance > directionChoice.Item2)
        {
            fruitDistance = directionChoice.Item2;
            Debug.Log("This is out of range of there max range!");
        }
        Vector3 pos = PosOnCircle(reachStartPos, fruitDistance, 180 + angleOffset + directionChoice.Item1, stats.chestHeight);
        fruitPos = pos;
        int index = UnityEngine.Random.Range(0, objects.Count);

        rpcHandle.SpawnRequest(objects[index].name, pos, "fruit");
        rpcHandle.TextUpdates("Look to the " + dirToText[(int)direction / 45]);

        if (!timerIsRunning)
            ToggleTimer(timeToReach);
    }
    public void ResetField()
    {
        StopAllCoroutines();
        controlVF.SetActive(false);
        startButton.SetActive(true);

        rpcHandle.TextUpdatesStatusOn(true);
        rpcHandle.TextUpdates(waitString);
        grabbingFruit = false;
        DestroyFruit();

        if (timerIsRunning)
        {
            ToggleTimer(timeToReach);
            DisplayTime(timeToReach);
        }

    }


    private Vector3 PosOnCircle(Vector3 center, float radius, float ang, float height)
    {
        Vector3 pos;
        pos.x = center.x + radius * Mathf.Sin(ang * Mathf.Deg2Rad);
        pos.z = center.z + radius * Mathf.Cos(ang * Mathf.Deg2Rad);
        pos.y = height;
        return pos;
    }



    public void FruitPickUp()
    {
        ding.Play();
        grabbingFruit = false;
        rpcHandle.TextUpdatesStatusOn(true);
        rpcHandle.TextUpdates(resetHandText.text);
    }

    public void TriggerDown(SteamVR_Action_Boolean fromAction, SteamVR_Input_Sources fromSource)
    {
    }

    public void LocateRpcHandler()
    {
        rpcHandle = FindObjectOfType<RpcHandler>();
    }

    private void DestroyFruit()
    {
        rpcHandle.DespawnRequest(rpcHandle.RetrRegObj("fruit"));
    }
}