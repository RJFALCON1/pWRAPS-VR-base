using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Valve.VR;

public class UpdateViveTracker : MonoBehaviour
{
    [SerializeField] public String chestSerialNumber;
    // Start is called before the first frame update
    void Start()
    {
        uint index = 0;
        var error = ETrackedPropertyError.TrackedProp_Success;
        if (OpenVR.System == null)
        {
            Debug.LogError("OpenVR.System is null!");
        }
        if (!found)
        {
            StringBuilder sb = new StringBuilder();
            for (uint i = 0; i < SteamVR.connected.Length; i++)
            {
                var result = new System.Text.StringBuilder((int)64);

                OpenVR.System.GetStringTrackedDeviceProperty((uint)i, ETrackedDeviceProperty.Prop_SerialNumber_String, sb, OpenVR.k_unMaxPropertyStringSize, ref error);
                var SerialNumber = sb.ToString();
                Debug.Log(i + "model nmber: " + SteamVR.instance.GetStringProperty(ETrackedDeviceProperty.Prop_ModelNumber_String, (uint)i) + "  " + SerialNumber);
            }
            GetComponent<SteamVR_TrackedObject>().index = (SteamVR_TrackedObject.EIndex)index;
            found = true;
        }
       

    }
    bool found = false;
}
