using System.IO;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PositionData
{
    public List<Vector3> positions = new List<Vector3>();
}

public class PositionLogger : MonoBehaviour
{
    private PositionData positionData = new PositionData();
    private string folderPath;

    void Start()
    {
        // Create the folder for saving JSON files in the project
        folderPath = Path.Combine(Application.dataPath, "TrackerPositions");
        if (!Directory.Exists(folderPath))
        {
            Directory.CreateDirectory(folderPath);
        }
    }

    public void SavePosition(Vector3 position)
    {
        // Add the position to the list
        positionData.positions.Add(position);
        
        // Create a unique filename based on timestamp
        string timestamp = System.DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string fileName = $"tracker_positions_{timestamp}.json";
        string filePath = Path.Combine(folderPath, fileName);
        
        // Convert the position data to JSON format and save it to the new file
        string jsonData = JsonUtility.ToJson(positionData, true);
        File.WriteAllText(filePath, jsonData);
        
        Debug.Log($"Position saved: {position}. JSON saved to: {filePath}");
    }
}
