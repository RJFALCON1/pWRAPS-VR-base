using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Valve.VR.InteractionSystem{
    public class ObjectSpawner : MonoBehaviour
    {
        [Header("Objects to Spawn")]
        public List<GameObject> objects = new List<GameObject>();
        public float minSpawnTime = 5f;
        public float maxSpawnTime = 15f;
        public float minMaxDistance = 3f;
        private float nextSpawnTime;
        //public GameObject ballPrefab;

        public bool autoSpawn = true;
        public bool spawnAtStartup = true;

        public float scale = 50f;
        
        // Start is called before the first frame update
        void Start()
        {
            if(objects.Count == 0){
                return;
            }
            if(autoSpawn && spawnAtStartup){
                SpawnObject();
            }
            nextSpawnTime = Random.Range( minSpawnTime, maxSpawnTime ) + Time.time;
        }

        // Update is called once per frame
        void Update()
        {
            if(objects.Count == 0){
                return;
            }
            if ( ( Time.time > nextSpawnTime ) && autoSpawn )
                {
                    SpawnObject();
                    nextSpawnTime = Random.Range( minSpawnTime, maxSpawnTime ) + Time.time;
                }
        }

        public GameObject SpawnObject(){
            if(objects.Count == 0){
                return null;
            }
            int index = Random.Range(0, objects.Count);
            float x = Random.Range(-minMaxDistance, minMaxDistance);
            GameObject thing = Instantiate(objects[index], transform.position + new Vector3(x, 0, 0), transform.rotation) as GameObject;
            thing.transform.localScale = new Vector3(scale, scale, scale);
            return thing;


        }
    }
}