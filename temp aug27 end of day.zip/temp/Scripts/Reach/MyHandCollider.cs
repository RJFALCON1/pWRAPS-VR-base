using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[RequireComponent(typeof(BoxCollider))]
public class MyHandCollider : MonoBehaviour
{
    public SignalSender grabbedFruit;
    private RpcHandler rpcHandle;

    private void Start()
    {
        rpcHandle = FindObjectOfType<RpcHandler>();
    }

    private void OnTriggerEnter(Collider other) {
        Debug.Log("Fruit in box");
        if(other.CompareTag("Fruit")){
            Debug.Log("Grabbed fruti!");
            grabbedFruit.Raise();
            rpcHandle.DespawnRequest(other.transform.gameObject);            
        }
    }
}
