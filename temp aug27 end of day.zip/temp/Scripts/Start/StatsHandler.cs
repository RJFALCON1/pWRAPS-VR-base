/* SceneHandler.cs*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Valve.VR.Extras;
using Valve.VR;
using Valve.VR.InteractionSystem;
using System.Globalization;
using System.IO;
using TMPro;
using System;
using UnityEngine.UIElements;
//https://sarthakghosh.medium.com/a-complete-guide-to-the-steamvr-2-0-input-system-in-unity-380e3b1b3311
//explains the user input from steamvr 2.0
public class StatsHandler : MonoBehaviour
{

    [Header("Controllers")]
    public SteamVR_Action_Boolean input;
    public SteamVR_Input_Sources handType;
    public GameObject pelvicBraceTracker;
    public GameObject chestTracker;
    public GameObject rightHand;
    public CharacterStats playerStats;
    public GameObject control;
    public GameObject player;

    [Header("Save Output")]
    private string saveFile;
    private JsonPlayerStats jsonStats = new JsonPlayerStats();


    [Header("Reach Targets")]
    public GameObject balloonE;
    public GameObject balloonNE;
    public GameObject balloonN;
    public GameObject balloonNW;
    public int currentBalloonIdx;
    private GameObject instantiatedBalloon;


    [Header("Instructions")]
    public TextMeshProUGUI armInstructions;
    public TextMeshProUGUI reachInstructions;

    private string[] balloons = new string[]{"BalloonE", "BalloonNE", "BalloonN", "BalloonNW"};


    [Header("Handle Text Fade In/Out")]
    public float timeMultiplier;

    /*[Header("Handle Puppet Fade In/Out")]
    public float fadeSpeed;
    private GameObject demoPuppet;*/

    //Keep a reference to the original chest position
    private Vector3 ogChestPos;

    private RpcHandler rpcHandle;


    private void Start() {
        input.AddOnStateDownListener(TriggerDown, handType);
        saveFile = Application.dataPath + "/Reports/";
        playerStats.Reset();
        playerStats.Reset();
        playerStats = new CharacterStats();
    }

    void Update()
    {
        if (Input.GetKeyDown("space"))
        {
            if (playerStats.armCalibration)
            {
                //during calibration mode and the player hits the finish button
                float distance = Vector3.Distance(rightHand.transform.position, chestTracker.transform.position);
                jsonStats.armsLength = distance;
                jsonStats.chestHeight = chestTracker.transform.position.y;
                jsonStats.userName = playerStats.userName;
                writeFile(jsonStats);
                Debug.Log("Saved Stats!");
                playerStats.armCalibration = false;
                control.GetComponent<StartManager>().Reset();
            }
        }
    }

    public void TriggerDown(SteamVR_Action_Boolean fromAction, SteamVR_Input_Sources fromSource)
    {
        
        if(playerStats.armCalibration){
            //Save the chest positoion so that we can calculate how far the max leaning distance
            ogChestPos = chestTracker.transform.position;

            float distance = Vector3.Distance(rightHand.transform.position, chestTracker.transform.position);
            //Json data
            jsonStats.armsLength = distance;
            jsonStats.chestHeight = chestTracker.transform.position.y;
            jsonStats.pelvicBraceHeight = pelvicBraceTracker.transform.position.y;
            jsonStats.userName = playerStats.userName;
            jsonStats.startPos = chestTracker.transform.position;
            //The current player jsonStats
            playerStats.chestHeight = jsonStats.chestHeight;
            playerStats.armsLength = jsonStats.armsLength;
            playerStats.armCalibration = false;
            playerStats.reachCalibration = true;

            currentBalloonIdx = 0;
            /* VR Legacy ----
             * demoPuppet.SetActive(false);
            armInstructions.gameObject.SetActive(false);
            */
            rpcHandle.TextUpdatesStatusOn(false);
            ReachCalibrateInstructions(currentBalloonIdx);
            
        }
        else if (playerStats.reachCalibration)
        {
            if (rpcHandle == null)
                rpcHandle = FindObjectOfType<RpcHandler>();

            instantiatedBalloon = rpcHandle.RetrRegObj(balloons[currentBalloonIdx]);
            if (instantiatedBalloon == null)
            {
                Debug.Log(balloons[currentBalloonIdx] + " does not yet exist, aborting");
                return;
            }
            switch (currentBalloonIdx)
            {
                //The balloon's dimensions are 0.27x0.36x0.27
                case 0:
                    jsonStats.maxReachE = (Vector3.Distance(instantiatedBalloon.transform.position, ogChestPos) - 0.27f / 2);
                    break;
                case 1:
                   
                    jsonStats.maxReachNE = Vector3.Distance(instantiatedBalloon.transform.GetChild(0).position, ogChestPos) - 0.191f;
                    break;
                case 2:
                    
                    jsonStats.maxReachN = (Vector3.Distance(instantiatedBalloon.transform.position, ogChestPos) - 0.27f / 2);
                    break;
                case 3:

                    jsonStats.maxReachNW = Vector3.Distance(instantiatedBalloon.transform.GetChild(0).position, ogChestPos) - 0.191f;
                    break;
            }
            //rpcHandle.DespawnRequest(instantiatedBalloon);

            if (currentBalloonIdx != 3)
            {
                rpcHandle.DespawnRequest(instantiatedBalloon);
                currentBalloonIdx++;
                ReachCalibrateInstructions(currentBalloonIdx);
            }
            else
            {
                currentBalloonIdx = 0;
                control.GetComponent<StartManager>().Reset();
                playerStats.reachCalibration = false;
                instantiatedBalloon.SetActive(false);
                rpcHandle.TextUpdatesStatusOn(false);

                writeFile(jsonStats);

                Debug.Log("Saved Stats!");
            }
        }
    }



    #region Instructions Display
    public void ArmLengthCalibrateInstructions()
    {
        if (rpcHandle == null)
            rpcHandle = FindObjectOfType<RpcHandler>();
        rpcHandle.TextUpdatesStatusOn(true);

        rpcHandle.TextUpdates("Reach out your arm straight with your chest upright");

        playerStats.armCalibration = true;

    }
    public void ReachCalibrateInstructions(int balloonIdx)
    {
        if (rpcHandle == null)
            rpcHandle = FindObjectOfType<RpcHandler>();

        Vector3 balloonPos = Vector3.zero;

        instantiatedBalloon = null;
        Debug.Log("Attempting to spawn " + balloons[balloonIdx]);
        switch (balloonIdx)
        {
            case 0:
                balloonPos = new Vector3(player.transform.position.x + jsonStats.armsLength, jsonStats.chestHeight, player.transform.position.z);
                
                playerStats.reachCalibration = true;
                rpcHandle.TextUpdatesStatusOn(true);
                rpcHandle.TextUpdates("Push each balloon as far as you can!");

                break;
            case 1:
                balloonPos = new Vector3((float)(player.transform.position.x + jsonStats.armsLength * Math.Cos(Math.PI / 4)), jsonStats.chestHeight, (float)(player.transform.position.z + jsonStats.armsLength * Math.Sin(Math.PI / 4)));
                break;
            case 2:
                balloonPos = new Vector3(player.transform.position.x, jsonStats.chestHeight, player.transform.position.z + jsonStats.armsLength);
                break;
            case 3:
                balloonPos = new Vector3((float)(player.transform.position.x - jsonStats.armsLength * Math.Cos(Math.PI / 4)), jsonStats.chestHeight, (float)(player.transform.position.z + jsonStats.armsLength * Math.Sin(Math.PI / 4)));
                break;
        }
        rpcHandle.SpawnRequest(balloons[balloonIdx], balloonPos, balloons[balloonIdx]);

    }
    public void Reset()
    {
        //return the ballooons back to their original position

        if (rpcHandle == null)
            rpcHandle = FindObjectOfType<RpcHandler>();

        if (instantiatedBalloon != null)
            rpcHandle.DespawnRequest(instantiatedBalloon);
        
        balloonE.SetActive(false);
        balloonN.SetActive(false);
        balloonNE.SetActive(false);
        balloonNW.SetActive(false);
        /* VR Legacy ---
         demoPuppet.SetActive(false);*/
        currentBalloonIdx = 0;
        playerStats.Reset();

        rpcHandle.TextUpdatesStatusOn(false);
        //reachInstructions.gameObject.SetActive(false);


        

    }
    #region Fade Fcns
    private IEnumerator FadeInText(float timeSpeed, TextMeshProUGUI text)
    {
        text.color = new Color(text.color.r, text.color.g, text.color.b, 0);
        while (text.color.a < 1.0f)
        {
            text.color = new Color(text.color.r, text.color.g, text.color.b, text.color.a + (Time.deltaTime * timeSpeed));
            yield return null;
        }
    }
    public IEnumerator FadeOutText(float timeSpeed, TextMeshProUGUI text)
    {
        text.color = new Color(text.color.r, text.color.g, text.color.b, 1);
        while (text.color.a > 0.0f)
        {
            text.color = new Color(text.color.r, text.color.g, text.color.b, text.color.a - (Time.deltaTime * timeSpeed));
            yield return null;
        }
    }
    #endregion

    #endregion
    #region JSON Stuff
    public class JsonPlayerStats
    {
        public float armsLength;
        public int run;
        public float pelvicBraceHeight;
        public float chestHeight;
        public string userName;
        //Use north, south, east, and west to designate which direction the user is leaning
        public float maxReachE;
        public float maxReachNE;
        public float maxReachN;
        public float maxReachNW;
        public Vector3 startPos;

    }

    public void writeFile(JsonPlayerStats stats)
    {
        // Serialize the object into JSON and save string.
        string jsonString = JsonUtility.ToJson(stats);
        string date = DateTime.Now.ToString("yyyy-MM-dd");
        // Write JSON to file.
        File.WriteAllText(Application.dataPath + "/Reports/" + stats.userName + "/" + date +"/" + stats.userName + "_Data.json", jsonString);
    }
    #endregion

}