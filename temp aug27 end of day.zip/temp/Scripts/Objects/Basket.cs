using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class Basket : MonoBehaviour
{
    public SignalSender updateRun;

    public CharacterStats stats;
    private AudioSource ding;
    private bool caught;
    private void Start() {
        //stats.Score = 0;
        //updateScore.Raise();
        ding = GetComponent<AudioSource>();
    }
    private void OnTriggerEnter(Collider other) {
        if (other != null)
        {
            if (other.CompareTag("Fruit") && !caught)
            {
                //fruit.caught = true;
                caught = true;
                stats.run++;
                StartCoroutine(Destroy(other) );
                   
                updateRun.Raise();
                ding.Play();
                //Debug.Log("Fruit in box");
            }
            //if (other.CompareTag("Fruit") && !fruit.caught)
            //{
            //    stats.Score++;
            //    Debug.Log("Score!  " + stats.Score.ToString());
            //    updateScore.Raise();
            //    ding.Play();
            //    if (this != null)
            //    {
            //        
            //    }
            //
            //
            //}
        }
    }
    private IEnumerator Destroy(Collider other)
    {
        yield return new WaitForSeconds(2);
        Destroy(this.transform.parent.gameObject);
        Destroy(other.gameObject);
    }
}
