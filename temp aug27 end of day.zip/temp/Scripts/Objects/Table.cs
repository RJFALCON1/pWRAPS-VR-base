using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Table : MonoBehaviour
{
    public GameObject rightHand;
    public GameObject leftHand;

    // Start is called before the first frame update
    void Start()
    {
        //Physics.IgnoreCollision(rightHand.GetComponent<HandCollider>(), GetComponent<HandCollider>());
        //Physics.IgnoreCollision(leftHand.GetComponent<HandCollider>(), GetComponent<HandCollider>());
    }

}
