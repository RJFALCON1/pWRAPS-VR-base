using RosMessageTypes.Chawi;
using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using Unity.Robotics.ROSTCPConnector.ROSGeometry;
using System.Collections;
/// <summary>
/// Example demonstration of implementing a UnityService that receives a Request message from another ROS node and sends a Response back
/// </summary>
public class RosReachVRService : MonoBehaviour
{
    [SerializeField]
    public string serviceName = "reach_vr_srv";
    public ReachManager reachManager;
    public PickUpManager pickUpManager;
    public ReachVRResponse reachResponse;

    void Start()
    {
        
        reachResponse.reach_success = false;
        // register the service with ROS
        ROSConnection.GetOrCreateInstance().ImplementService<ReachVRRequest, ReachVRResponse>(serviceName, GetResponse);
    }

    float timer = 0;
    bool timerReached = false;
    bool startTimeCount = false;
    private ReachVRResponse GetResponse(ReachVRRequest request)
    {
        Debug.Log("Received!");
        reachResponse = new ReachVRResponse();
        float startTime = Time.time;
        timer = 0;
        timerReached = false;
        
        Debug.Log("Service called!");

        Debug.Log(request.ToString());
        //Update the game with the request parameters
        bool record = false;
        bool cntrlF = true;

        if (request.vr_condition == "non")
            record = true;


        if (reachManager != null)
        {
            if (request.vr_condition == "ctl")
                cntrlF = true;
            else if (request.vr_condition == "err")
                cntrlF = false;
            reachManager.timeToReach = request.time_limit;
            reachManager.StartGame(request.direction_deg, request.height_pc_torso, request.distance_pc_max, request.speed, record, cntrlF, request.rep);
        }
        Debug.Log(request.vr_condition);

        //while (reachManager.timerIsRunning) { }
        
        //var done = StartCoroutine(WaitForSecs(request.time_limit));
        reachResponse.reach_success = true;
        Debug.Log("Sending response: " + reachResponse.ToString());

        //GetGeometryPoint(reachManager.handTracker.transform.position.Unity2Ros(), response.target_position.point);


        return reachResponse;
    }

    IEnumerator WaitForSecs(float time)
    {
        //Print the time of when the function is first called.
        Debug.Log("Started Coroutine at timestamp : " + Time.time);

        //yield on a new YieldInstruction that waits for 5 seconds.
        yield return new WaitForSeconds(time);

        yield return true;
        //After we have waited 5 seconds print the time again.
        Debug.Log("Finished Coroutine at timestamp : " + Time.time);
    }
}