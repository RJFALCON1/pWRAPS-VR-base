using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Valve.VR;
using UnityEditor.UI;

public class UpdateViveTracker : MonoBehaviour
{
    [SerializeField] public String SerialNumber;
    /*
     * There are 11 objects connected to the SteamVR.
     * Valve SR Imp - camera trackers
     * VIVE Tracker Pro - trackers
     * VIVE Controller
     * VIVE_Pro
     */
    void Start()
    {
        var error = ETrackedPropertyError.TrackedProp_Success;

        for (int i = 0; i < 11; i++)    // technically 0, and 7-10 are HMD and cameras but in here for thoroughness
        {
            StringBuilder sb = new StringBuilder();
            var result = new System.Text.StringBuilder((int)64);

            OpenVR.System.GetStringTrackedDeviceProperty((uint)i, ETrackedDeviceProperty.Prop_SerialNumber_String, sb, OpenVR.k_unMaxPropertyStringSize, ref error);
            string foundSerial = sb.ToString();
            if (foundSerial == SerialNumber)
            {
                GetComponent<SteamVR_TrackedObject>().index = (SteamVR_TrackedObject.EIndex)i;
            }
        }
        /* Use this line to recalibrate */
        //Debug.Log(i + " model number: " + SteamVR.instance.GetStringProperty(ETrackedDeviceProperty.Prop_ModelNumber_String, (uint)i) + "  " + foundSerial);

    }
}
