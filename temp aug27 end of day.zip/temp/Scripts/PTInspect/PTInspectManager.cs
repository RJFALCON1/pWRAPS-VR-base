using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using Newtonsoft.Json;

public class PTInspectManager : MonoBehaviour
{
    [Header("Stand Placeholders")]
    public GameObject[] standPlaceholders;

    [Header("Text Instructions")]
    public TextMeshPro[] standTexts;

    [Header("Confirmation Button")]
    public Button confirmPositionButton;

    [Header("Position Logger")]
    public PositionLogger positionLogger;

    [Header("Patient Data")]
    public StatsHandler statsHandler;

    [Header("Tracker")]
    public GameObject chestTracker;

    private int currentStandPositionIndex = 0;

    void Start()
    {
        SetNextStandPosition();
    }

    void SetNextStandPosition()
    {
        if (currentStandPositionIndex >= standPlaceholders.Length)
        {
            
            foreach (var text in standTexts)
                text.gameObject.SetActive(false);

            foreach (var stand in standPlaceholders)
                stand.SetActive(false);

            confirmPositionButton.gameObject.SetActive(false);
            return;
        }

        
        for (int i = 0; i < standPlaceholders.Length; i++)
        {
            standPlaceholders[i].SetActive(i == currentStandPositionIndex);
            standTexts[i].gameObject.SetActive(i == currentStandPositionIndex);
        }

        
        standTexts[currentStandPositionIndex].text = "Move the stand here!";
    }

    public void ConfirmStandPosition()
    {
        Vector3 trackerPosition = chestTracker.transform.position;

        // Update the stats based on the current stand position
        switch (currentStandPositionIndex)
        {
            case 0:
                statsHandler.playerStats.maxReachE = trackerPosition.x;
                positionLogger.SavePosition("StandE", trackerPosition);
                break;
            case 1:
                statsHandler.playerStats.maxReachNE = trackerPosition.x;
                positionLogger.SavePosition("StandNE", trackerPosition);
                break;
            case 2:
                statsHandler.playerStats.maxReachN = trackerPosition.z;
                positionLogger.SavePosition("StandN", trackerPosition);
                break;
            case 3:
                statsHandler.playerStats.maxReachNW = trackerPosition.x;
                positionLogger.SavePosition("StandNW", trackerPosition);
                break;
        }

        Debug.Log($"Confirmed tracker position: {trackerPosition}");
        currentStandPositionIndex++;
        SetNextStandPosition();

        confirmPositionButton.onClick.RemoveListener(ConfirmStandPosition);
    }
}