using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class PTInspectManager : MonoBehaviour
{
    [Header("Stand Placeholder")]
    public GameObject standPlaceholder;
    public TextMeshPro standText;

    [Header("Confirmation Button")]
    public Button confirmPositionButton;

    [Header("Patient Data")]
    public StatsHandler statsHandler;

    [Header("Tracker")]
    public GameObject chestTracker;

    private int currentStandPositionIndex = 0;
    public Vector3[] standPositions;

    void Start()
    {
        InitializeStandPositions();
        SetNextStandPosition();
    }

    void InitializeStandPositions()
    {

        standPositions = new Vector3[]
        {
            new Vector3(statsHandler.playerStats.maxReachE, statsHandler.playerStats.chestHeight, transform.position.z),
            new Vector3((float)(transform.position.x + statsHandler.playerStats.maxReachNE * Mathf.Cos(Mathf.PI / 4)), statsHandler.playerStats.chestHeight, (float)(transform.position.z + statsHandler.playerStats.maxReachNE * Mathf.Sin(Mathf.PI / 4))),
            new Vector3(transform.position.x, statsHandler.playerStats.chestHeight, transform.position.z + statsHandler.playerStats.maxReachN),
            new Vector3((float)(transform.position.x - statsHandler.playerStats.maxReachNW * Mathf.Cos(Mathf.PI / 4)), statsHandler.playerStats.chestHeight, (float)(transform.position.z + statsHandler.playerStats.maxReachNW * Mathf.Sin(Mathf.PI / 4)))
        };
    }

    void SetNextStandPosition()
    {

        if (currentStandPositionIndex >= standPositions.Length)
        {
            standText.text = "Calibration Complete!";
            confirmPositionButton.gameObject.SetActive(false);
            return;
        }


        standPlaceholder.transform.position = standPositions[currentStandPositionIndex];
        standText.text = "Move the stand here!";
        confirmPositionButton.onClick.AddListener(ConfirmStandPosition);
    }

    public void ConfirmStandPosition()
    {
        
        Vector3 trackerPosition = chestTracker.transform.position;
        switch (currentStandPositionIndex)
        {
            case 0:
                statsHandler.playerStats.maxReachE = trackerPosition.x;
                break;
            case 1:
                statsHandler.playerStats.maxReachNE = trackerPosition.x;
                break;
            case 2:
                statsHandler.playerStats.maxReachN = trackerPosition.z;
                break;
            case 3:
                statsHandler.playerStats.maxReachNW = trackerPosition.x;
                break;
        }

        Debug.Log($"Confirmed tracker position: {trackerPosition}");
        currentStandPositionIndex++;
        SetNextStandPosition();


        confirmPositionButton.onClick.RemoveListener(ConfirmStandPosition);
    }
}
