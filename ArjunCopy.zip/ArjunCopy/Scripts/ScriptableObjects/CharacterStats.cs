using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "ScriptableObjects/Stats", fileName = "NewStats")]
public class CharacterStats : ScriptableObject
{
    public int run;
    public float armsLength;

    public float chestHeight;
    public float pelvicBraceHeight;
    public string userName;
    //Use north, south, east, and west to designate which direction the user is leaning
    public float maxReachE;
    public float maxReachNE;
    public float maxReachN;
    public float maxReachNW;

    public bool armCalibration = false;
    public bool reachCalibration = false;
    public Vector3 startPos;

    public void Reset()
    {
        run = 0;
        armsLength = 0;
        chestHeight = 0;
        pelvicBraceHeight = 0;
        userName = "";
        maxReachE = 0;
        maxReachN = 0;
        maxReachNE = 0;
        maxReachNW = 0;
        armCalibration = false;
        reachCalibration = false;
        startPos = Vector3.zero;
    }

}
